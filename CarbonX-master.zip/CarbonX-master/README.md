# CarbonX
A free level 7 roblox executor!

### There is no need to worry about this repository, as it only will contain ZIPS and links for the Bootstrapper and the main program.